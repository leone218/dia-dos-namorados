document.getElementById('revealButton').addEventListener('click', function () {
  const message = document.getElementById('message');
  message.classList.remove('hidden');
  this.style.display = 'none';
});